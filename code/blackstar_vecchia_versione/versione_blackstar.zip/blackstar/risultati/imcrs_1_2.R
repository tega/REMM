z.imcrs1 <- function ()
{
  dati_read.table("mc_results_step_1.dat",header = FALSE, sep = "") 
  dati_data.frame( dati[,-1]) 
  d_dim (dati)
  X_matrix(0,d[1],d[2])
  variable.names_c("convergence","iterations")
  for (i in 3:(d[2]))
    {
      variable.names_c(variable.names,paste("theta",i-2,sep=""))
    }
  for (i in 1:d[2])
    {
      X[,i]_dati[,i]
    }
  dimnames(X)_list(NULL,variable.names)
  return (X)
}


z.imcrs2 <- function ()
{
  dati_read.table("mc_results_step_2.dat",header = FALSE, sep = "")
  dati_data.frame( dati[,-1])
  d_dim (dati)
  X_matrix(0,d[1],d[2])
  variable.names_c("convergence","iterations")
  for (i in 3:(d[2]))
    {
      variable.names_c(variable.names,paste("rho",i-2,sep=""))
    }
  for (i in 1:d[2])
    {
      X[,i]_dati[,i]
    }
  dimnames(X)_list(NULL,variable.names)
  return (X)
}

z.imcrs1.rob <- function ()
{
  dati_read.table("mc_results_step_1_rob.dat",header = FALSE, sep = "") 
  dati_data.frame( dati[,-1]) 
  d_dim (dati)
  X_matrix(0,d[1],d[2])
  variable.names_c("convergence.rob","iterations.rob","conv.snp", "iter.snp")
  for (i in 5:(d[2]))
    {
      variable.names_c(variable.names,paste("theta",i-4,sep=""))
    }
  for (i in 1:d[2])
    {
      X[,i]_dati[,i]
    }
  dimnames(X)_list(NULL,variable.names)
  return (X)
}


z.imcrs2.rob <- function ()
{
  dati <- read.table("mc_results_step_2_rob.dat",header = FALSE, sep = "") 
  dati <- data.frame( dati[,-1]) 
  d <- dim (dati)
  X <- matrix(0,d[1],d[2])
  variable.names <- c("convergence.rob","iterations.rob","conv.snp","iter.snp")
  for (i in 5:(d[2]))
    {
      variable.names <- c(variable.names,paste("rho",i-4,sep=""))
    }
  for (i in 1:d[2])
    {
      X[,i] <- dati[,i]
    }
  dimnames(X) <- list(NULL,variable.names)
  return (X)
}


z.monte.carlo <- function ()
{
  L <- list (F)
  name <- "Bool"
  
  
  if (file.exists("mc_results_step_1.dat"))
    {
      name <- c(name,"res.theta")
      L[[length(L)+1]] <- z.imcrs1()
    }
  
  
  if (file.exists("mc_results_step_2.dat"))
    {
      name <- c(name,"res.rho")
      L[[length(L)+1]] <- z.imcrs2()
    }
  

  if (file.exists("mc_results_step_1_rob.dat"))
    {
      name <- c(name,"res.theta.rob")
      L[[length(L)+1]] <- z.imcrs1.rob()
    }
  
  
  if (file.exists("mc_results_step_2_rob.dat"))
    {
      name <- c(name,"res.rho.rob")
      L[[length(L)+1]] <- z.imcrs2.rob()
    }
  
  
  if (file.exists("series_iid.dat"))
    {
      dati <- read.table("series_iid.dat",header = FALSE, sep = "")
      d <- dim (dati)
      iid <- matrix(0,d[1],d[2])
      variable.names <- "iid.1"
      if (d[2]>1)
        {
          for (i in 2:(d[2]))
            {
              variable.names <- c(variable.names,paste("iid.",i,sep=""))
            }
        }
      for (i in 1:d[2])
        {
          iid[,i] <- dati[,i]
        }
      dimnames(iid) <- list(NULL,variable.names)
      name <- c(name,"iid")
      L[[length(L)+1]] <- iid
    }
  
  
  if (file.exists("series_iid_for_step_2.dat"))
    {
      dati <- read.table("series_iid_for_step_2.dat",header = FALSE, sep = "")
      d <- dim (dati)
      iid.step.2 <- matrix(0,d[1],d[2])
      variable.names <- "iid.step.2.1"
      if (d[2]>1)
        {
          for (i in 2:(d[2]))
            {
              variable.names <- c(variable.names,paste("iid.step.2.",i,sep=""))
            }
        }
      for (i in 1:d[2])
        {
          iid.step.2[,i] <- dati[,i]
        }
      dimnames(iid.step.2) <- list(NULL,variable.names)
      name <- c(name,"iid.step.2")
      L[[length(L)+1]] <- iid.step.2
    }
  

  if (file.exists("series_uncontaminated.dat"))
    {
      dati <- read.table("series_uncontaminated.dat",header = FALSE, sep = "")
      d <- dim (dati)
      series <- vector(mode = "numeric", length = d[1])
      series <- dati[,1]
      name <- c(name,"series")
      L[[length(L)+1]] <- series
    }

  
  if (file.exists("series_contaminated.dat"))
    {
      dati <- read.table("series_contaminated.dat",header = FALSE, sep = "")
      d <- dim (dati)
      series.c <- vector(mode = "numeric", length = d[1])
      series.c <- dati[,1]
      name <- c(name,"series.c")
      L[[length(L)+1]] <- series.c
    }


  if (file.exists("series_not_observable_uncontaminated.dat"))
    {
      dati <- read.table("series_not_observable_uncontaminated.dat",header = FALSE, sep = "")
      d <- dim (dati)
      series.not.obs <- vector(mode = "numeric", length = d[1])
      series.not.obs <- dati[,1]
      name <- c(name,"series.not.obs")
      L[[length(L)+1]] <- series.not.obs
    }

  
  if (file.exists("series_not_observable_contaminated.dat"))
    {
      dati <- read.table("series_not_observable_contaminated.dat",header = FALSE, sep = "")
      d <- dim (dati)
      series.not.obs.c <- vector(mode = "numeric", length = d[1])
      series.not.obs.c <- dati[,1]
      name <- c(name,"series.not.obs.c")
      L[[length(L)+1]] <- series.not.obs.c
    }
  
  
  if (file.exists("series_weights.dat"))
    {
      dati <- read.table("series_weights.dat",header = FALSE, sep = "")
      d <- dim (dati)
      weights <- vector(mode = "numeric", length = d[1])
      weights <- dati[,1]
      name <- c(name,"weights")
      L[[length(L)+1]] <- weights
    }
  
  
  names(L) <- name  
  return(L)
}


z.diff.class.rob <- function (a)
{
  #first the theta coefficient
  converged <- a$res.theta[,1]==0
  converged <- a$res.theta.rob[,1]==0 & converged
  d <- dim (a$res.theta)
  ac2 <- d[2]
  d <- dim (a$res.theta.rob)
  ar2 <- d[2]
  X1 <- a$res.theta[converged,3:ac2]
  Y1 <- a$res.theta.rob[converged,5:ar2]
  c <- X1 - Y1
  d <- dim(c)
  true.theta_c(0,0.4125,0.22,0.1375,0.815)
  #compute the 0.25 and 0.75 quantile
  S <- matrix(0,2,5)
  for (i in 1:5)
    {
      S[1,i] <- quantile(X1[,i],0.25)
      S[2,i] <- quantile(X1[,i],0.75)
    }


  par(mfrow=c(2,3)) 
  for (i in 1:d[2])
    {
      plot(density(c[,i]), ylab=paste(i,"component of theta"), 
           main=paste(formatC(S[1,i],digits=3,format="f"), "/", true.theta[i],
             "/", formatC(S[2,i],digits=3,format="f")), xlab=expression(hat(theta) - hat(theta[r]))) 
    }


  #then the rho coefficient
  converged <- a$res.rho[,1]==0
  converged <- a$res.rho.rob[,1]==0 & converged
  d <- dim (a$res.rho)
  ac2 <- d[2]
  d <- dim (a$res.rho.rob)
  ar2 <- d[2]
  X2 <- a$res.rho[converged,3:ac2]
  Y2 <- a$res.rho.rob[converged,5:ar2]
  d <- dim (a$res.rho)
  ac2 <- d[2]
  d <- dim (a$res.rho.rob)
  ar2 <- d[2]
  c <- X2 - Y2
  d <- dim(c)
  true.rho_c(0,0.9,0.81,-0.5)
  #compute the 0.25 and 0.75 quantile
  S <- matrix(0,2,4)
  for (i in 1:4)
    {
      S[1,i] <- quantile(X2[,i],0.25)
      S[2,i] <- quantile(X2[,i],0.75)
    }
  par(ask=T)
  par(mfrow=c(2,2)) 
  for (i in 1:d[2])
    {
      plot(density(c[,i]), ylab=paste(i,"component of rho "), 
           main=paste(formatC(S[1,i],digits=3,format="f"), "/", true.rho[i],
             "/", formatC(S[2,i],digits=3,format="f")), xlab=expression(hat(rho) - hat(rho[r]))) 
    }
  
}

z.converged.rob <- function(X)
{
  converged1 <- X[,1]==0 
  converged2 <- (X[,3]==0 | X[,3]==1)
  return(converged1 & converged2)
}


z.coeff <- function (X,obj=0)
{
   #X e' una matrice contenente i coeff. stimati
  d <- dim (X)
  names.col <- c(dimnames(X)[[2]])
  nb.simulations <- d[1]
  cex.main1_2.5
  cex.lab1_1.5
  cex.axis1_1.5
  #se il numero di simulazioni e' uguale a 1 termina
  if (nb.simulations==1)
    {
     return(print("Il numero di simulazioni e' 1"))
    }

  if (obj == 0)
    {
      start.col <- 3
      nb.param <- d[2]-start.col+1
      nome.file <- ".eps"
      estimation.kind <- "EMM"
    }
  else
    {
      start.col <- 5
      nb.param <- d[2]-start.col+1
      nome.file  <- ".rob.eps"
      estimation.kind <- "REMM"
    }
  
  #calcola il numero di simulazioni, quante di esse sono convergenti
  #e qualche statistica sui parametri
  cat("Statistiche:\n")
  cat("\n")
  cat("Numero di simulazioni...",nb.simulations,"\n")
  cat("\n")
  S <- matrix(0,7,nb.param)
  my.col <- start.col:d[2]
  names.row <- c("Media","Mediana","q25","q75","Stdv","q75-q25","MSE")
  dimnames(S) <- list(names.row,names.col[start.col:d[2]])
  #determina se ho a che fare con theta o rho
  if (substr(names.col[start.col],1,3)=="rho")
    {
      is.rho  <-  T
      true.parameters <- matrix(c(0,0.9,0.81,-0.5),1,nb.param)
      print(true.parameters)
    }
  else
    {
      is.rho <- F
      true.parameters <- matrix(c(0,0.4125,0.22,0.1375,0.8115),1,nb.param)
      print("true parameters:")
      print(true.parameters)
    }
  S[1,] <- apply(X[,my.col],2,mean)
  S[2,] <- apply(X[,my.col],2,median)
  for (i in my.col)
    {
       S[3,i-start.col+1] <- quantile(X[,i],0.25)
       S[4,i-start.col+1] <- quantile(X[,i],0.75)
       S[6,i-start.col+1] <- S[4,i-start.col+1] - S[3,i-start.col+1]
    }
  S[5,] <- sqrt(apply(X[,my.col],2,var))
  S[7,] <- S[5,]^2 + (S[1,]-true.parameters)^2
  print(formatC(S,format="f",digits = 4))
  cat("\n")

  #calcola come sopra ma solo sulle simulazioni convergenti
  converged <- X[,1]==0
  nb.of.converged <- sum(converged)
  cat("Numero di simulazioni convergenti......",nb.of.converged,"(",
      nb.of.converged/nb.simulations*100,"%)","\n")
  cat("\n")
  S[1,] <- apply(X[converged,start.col:d[2]],2,mean)
  S[2,] <- apply(X[converged,start.col:d[2]],2,median)
  for (i in my.col)
    {
       S[3,i-start.col+1] <- quantile(X[converged,i],0.25)
       S[4,i-start.col+1] <- quantile(X[converged,i],0.75)
       S[6,i-start.col+1] <- S[4,i-start.col+1] - S[3,i-start.col+1]
    }
  S[5,] <- sqrt(apply(X[converged,start.col:d[2]],2,var))
  S[7,] <- S[5,]^2 + (S[1,]-true.parameters)^2
  print(formatC(S,format="f",digits = 4))
  cat("\n")

  #calcola come sopra ma solo sulle simulazioni non convergenti
  nb.of.not.converged  <- nb.simulations-nb.of.converged
  if (nb.of.not.converged>1)
    {
      not.converged <- !converged
      cat("Numero di simulazioni non convergenti......",nb.of.not.converged,"(",
          nb.of.not.converged/nb.simulations*100,"%)","\n")
      cat("\n") 
      S[1,] <- apply(X[not.converged,start.col:d[2]],2,mean)
      S[2,] <- apply(X[not.converged,start.col:d[2]],2,median)
      for (i in my.col)
      {
        S[3,i-start.col+1] <- quantile(X[not.converged,i],0.25)
        S[4,i-start.col+1] <- quantile(X[not.converged,i],0.75)
        S[6,i-start.col+1] <- S[4,i-start.col+1] - S[3,i-start.col+1]
      }
      S[5,] <- sqrt(apply(X[not.converged,start.col:d[2]],2,var))
      S[7,] <- S[5,]^2 + (S[1,]-true.parameters)^2
      print(formatC(S,format="f",digits = 4))
      cat("\n")
    }
  #salva i valori di par
  par.old <- par()
  par(mfrow=c(1,1),mai=c(0.5,1,0.5,0),fin=c(6.8,6.8),pin=c(5,5))  
  #per TUTTE le simulazioni
  #fai un loop su tutti i coefficienti stimati e:
  #-calcola la media e diviazione standard
  #se varianza != 0 fai un:
  #-plot della densita' stimata paragonato alla normale
  #-boxplot
  #-istogramma
  for (i in start.col:d[2])
    {
      m <- mean(X[,i])
      ss <- sqrt(var(X[,i]))
      if (ss!=0) 
        { 
          par(ask=T)
          #plot density
          s <- density(X[,i])
          xlab <- paste("N =", s$n, "  Bandwidth =", formatC(s$bw))
          if (is.rho)
            {
              plot(s$x,s$y,type="l",main=substitute(paste(a,": Estimated density of ",
                   hat(rho)[ii],sep=""),list(a=estimation.kind,ii=i-start.col+1)),
                   ,xlab=xlab,ylab="Density",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
            }
          else
            {
              plot(s$x,s$y,type="l",main=substitute(paste(a,": Estimated density of ",
                   hat(theta)[ii],sep=""),list(a=estimation.kind,ii=i-start.col+1)),
                   ,xlab=xlab,ylab="Density",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
            }
          abline(h = 0, lwd = 0.1, col = "gray")
          #boxplot
          # xlab <- paste("Mean =", formatC(m), "Stdv =", formatC(ss))
          # boxplot(X[,i],xlab=xlab)
          # stringa <- paste("Boxplot of",names.col[i])
          # title (stringa)
          #histogram
           stringa <- paste("Histogram of",names.col[i])
           hist(X[,i],xlab=names.col[i],main=stringa)
          qqnorm
          if (is.rho)
            {
              qqnorm((X[,i]-m)/ss,main=substitute(paste(a,": Normal QQ-Plot of ",hat(rho)[ii],sep=""),
                                    list(a=estimation.kind,ii=i-start.col+1)),
                                    cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
            }
          else
            {
              qqnorm((X[,i]-m)/ss,main=substitute(paste(a,": Normal QQ-Plot of ",hat(theta)[ii],sep=""),
                                    list(a=estimation.kind,ii=i-start.col+1)),
                                    cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
            }
          abline(0,1)
        }
    }


  #solo per le simulazioni CONVERGENTI !!!!!
  #fai un loop su tutti i coefficienti stimati e:
  #-calcola la media e diviazione standard
  #se varianza != 0 fai un:
  #-plot della densita' stimata paragonato alla normale
  #-boxplot
  #-istogramma
  if (nb.of.converged>1)
    {
      for (i in start.col:d[2])
        {
          m <- mean(X[converged,i])
          ss <- sqrt(var(X[converged,i]))
          if (ss!=0 & nb.of.converged>1) 
            { 
              par(ask=T)
              postscript(paste(names.col[i],".d",nome.file,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
              #plot density
              s <- density(X[converged,i])
              xlab <- paste("Obs. =", s$n, "  Bandwidth =", formatC(s$bw))
              if (is.rho)
                {

                  plot(s$x,s$y,type="l",xlab=xlab,ylab="Density",main=substitute(paste
                  (a,": Estimated density of ",hat(rho)[ii]),list(a=estimation.kind,ii=i-start.col+1)),
                  cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              else
                {
                  plot(s$x,s$y,type="l",xlab=xlab,ylab="",main=substitute(paste
                  (a,": Estimated density of ",hat(theta)[ii]),list(a=estimation.kind,ii=i-start.col+1)),
                  cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              abline(h = 0, lwd = 0.1, col = "gray")
              dev.off()
              #boxplot
              # xlab <- paste("Mean =", formatC(m), "Stdv =", formatC(ss))
              # boxplot(X[,i],xlab=xlab,main=paste("Boxplot of",names.col[i]))
              #histogram         
               hist(X[converged,i],xlab=names.col[i],main=paste("Histogram of",names.col[i]))
              qqnorm
              postscript(paste(names.col[i],".q",nome.file,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
              if (is.rho)
                {
                  qqnorm((X[converged,i]-m)/ss,main=substitute(paste
                  (a,": Normal QQ-Plot of ",hat(rho)[ii]),list(a=estimation.kind,ii=i-start.col+1)),
                   cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              else
                {
                  qqnorm((X[converged,i]-m)/ss,main=substitute(paste
                  (a,": Normal QQ-Plot of ",hat(theta)[ii]),list(a=estimation.kind,ii=i-start.col+1)),
                  cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              abline(0,1)
              dev.off()
            }
        }
    }

  #solo per le simulazioni NON CONVERGENTI !!!!!
  #fai un loop su tutti i coefficienti stimati e:
  #-calcola la media e diviazione standard
  #se varianza != 0 fai un:
  #-plot della densita' stimata paragonato alla normale
  #-boxplot
  #-istogramma
  if (nb.of.not.converged>1)
    {
      for (i in start.col:d[2])
        {
          m <- mean(X[not.converged,i])
          ss <- sqrt(var(X[not.converged,i]))
          if (ss!=0) 
            { 
              par(ask=T)
              #plot density         
              s <- density(X[not.converged,i])
              xlab <- paste("N =", s$n, "  Bandwidth =", formatC(s$bw))
              if (is.rho)
                {
                  plot(s$x,s$y,type="l",xlab=xlab,ylab=paste("Density of",names.col[i]), 
                   main=substitute(paste(a,": Density estimation of ",hat(rho)[ii],
                     " (not converged simulations)",sep=""),
                   list(a=estimation.kind,ii=i-start.col+1)),
                   cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              else
                {
                  plot(s$x,s$y,type="l",xlab=xlab,ylab=paste("Density of",names.col[i]), 
                   main=substitute(paste(a,": Density estimation of ",hat(theta)[ii],
                     " (not converged simulations)",sep=""),
                   list(a=estimation.kind,ii=i-start.col+1)),
                   cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              abline(h = 0, lwd = 0.1, col = "gray")
              #boxplot
              # xlab <- paste("Mean =", formatC(m), "Stdv =", formatC(ss))
              # boxplot(X[,i],xlab=xlab,main=paste("Boxplot of",names.col[i],"\n","(not converged)"))
              #histogram  
              # hist(X[!converged,i],xlab=names.col[i],main=paste("Histogram of",names.col[i],
              #        "\n","(not converged)"))
              #qqnorm
              if (is.rho)
                {
                  qqnorm((X[not.converged,i]-m)/ss,main=substitute(paste(a,": Normal QQ-Plot of ",
                    hat(rho)[ii],
                    " (not converged simulations)"),list(a=estimation.kind,ii=i-start.col+1)),
                   cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              else
                {
                  qqnorm((X[not.converged,i]-m)/ss,main=substitute(paste(a,": Normal QQ-Plot of ",
                    hat(theta)[ii],
                           " (not converged simulations)"),list(a=estimation.kind,ii=i-start.col+1)),
                    cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                }
              abline(0,1)
            }
        }
    }
  par <- par.old
}


z.compare.algorithm <- function(X.old,X.new,coef="rho",cont=" ")
{
  d_dim(X.old)
  cex.main1_2
  cex.lab1_1.2
  cex.axis1_1.2
  for (i in 5:d[2])
    { 
      par(ask=T)
      par(mfrow=c(1,1),mar=c(2,2,3,1))
      #plot density         
      s1 <- density(X.old[,i]) #determine maximal common x range
      s2 <- density(X.new[,i])
      n1 <- length(s1$x)
      n2 <- length(s2$x)             
      from <- min(s1$x[1],s2$x[1])
      to <- max(s1$x[n1],s2$x[n2])
      n <- max(n1,n2)
      s1 <- density(X.old[,i],n=n,from=from,to=to) #compute both densities (jj~robust)            
      s2 <- density(X.new[,i],n=n,from=from,to=to)
      maximum <- max(max(s1$y),s2$y) #compute maximal y value
      xlab <- ""
      if (coef=="rho")
      {
        plot(s1$x,s1$y,type="l",lwd=2,main=substitute(paste("Estimated densities of ",
           hat(rho)[ii],sep=""),list(ii=i-4)),
           xlab=xlab,ylab="",ylim=c(0,maximum*1.1),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1) 
      }
      else
      {
      plot(s2$x,s2$y,type="l",lwd=2,main=substitute(paste("Estimated densities of ",
           hat(theta)[ii],sep=""),list(ii=i-4)),
           xlab=xlab,ylab="",ylim=c(0,maximum*1.1),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      }
      lines(s1$x,s1$y,type="l",lty=2,lwd=2)
      abline(h = 0, lwd = 0.1, col = "gray")
      legend(s2$x[1], maximum*1.15,lty=c(1,2),lwd=2,c("Fisher consistent REMM","REMM"), cex=1.3,horiz=T,y.intersp=1.3,bty="n")
    }

  for (i in 5:d[2])
    {
      if (cont=="contaminated")
      {
       name <- paste(coef,i-4,".alg.contaminated.eps",sep="")
      }
      else
      {
       name <- paste(coef,i-4,".alg.eps",sep="")
      }
      postscript(name,horizontal=FALSE,onefile=FALSE,height=4.5,width=6) #open output file
      par(mfrow=c(1,1),mar=c(2,2,3,1))
      #plot density         
      s1 <- density(X.old[,i]) #determine maximal common x range
      s2 <- density(X.new[,i])
      n1 <- length(s1$x)
      n2 <- length(s2$x)             
      from <- min(s1$x[1],s2$x[1])
      to <- max(s1$x[n1],s2$x[n2])
      n <- max(n1,n2)
      s1 <- density(X.old[,i],n=n,from=from,to=to) #compute both densities (jj~robust)            
      s2 <- density(X.new[,i],n=n,from=from,to=to)
      maximum <- max(max(s1$y),s2$y) #compute maximal y value
      xlab <- ""
      if (coef=="rho")
      {
        plot(s1$x,s1$y,type="l",lwd=2,main=substitute(paste("Estimated densities of ",
           hat(rho)[ii],sep=""),list(ii=i-4)),
           xlab=xlab,ylab="",ylim=c(0,maximum*1.1),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1) 
      }
      else
      {
        plot(s2$x,s2$y,type="l",lwd=2,main=substitute(paste("Estimated densities of ",
           hat(theta)[ii],sep=""),list(ii=i-4)),
           xlab=xlab,ylab="",ylim=c(0,maximum*1.1),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      }
      lines(s1$x,s1$y,type="l",lty=2,lwd=2)
      abline(h = 0, lwd = 0.1, col = "gray")
      legend(s2$x[1], maximum*1.15,lty=c(1,2),lwd=2,c("Fisher consistent REMM", "REMM"), cex=1.3,horiz=T,y.intersp=1.3,bty="n")
    dev.off() #close device, i.e. output file
    } 
}


z.compare.coeff <- function(A)
{
  step <- c("step1","step2")
  res <- c("res.theta","res.rho")
  res.rob <- c("res.theta.rob","res.rho.rob")
  name.coeff <- c("theta","rho")
  
  cex.main1_2
  cex.lab1_1.2
  cex.axis1_1.2

  #fai le statistiche 1) per tutte le simulazioni
  #                   2) solo di quelle convergenti
  #dapprima verifica che res.theta e res.theta.rob (res.rho e res.rho.rob) esistano
  for (q in 1:2)
    {
      i <- FALSE
      j <- FALSE
      s <- 1
      name <- names(A)
      for (nome in name)
        {
          if (nome==res[q]) 
            {
              i <- TRUE
              ii <- s
            }
          if (nome==res.rob[q])
            {
              j <- TRUE
              jj <- s
            }
          if (i & j) break
          s <- s+1
        }
      if (i & j)
        {
        #A e' una matrice contenente i coeff. stimati
          d <- dim (A[[ii]])
          names.col <- c(dimnames(A[[ii]])[[2]])
        
        #se il numero di simulazioni e' uguale a 1 termina

          if (d[1]==1)
            {
              return(print("Il numero di simulazioni e' 1"))
            }
          for (i in 3:d[2])
            { 
              par(ask=T)
              par(mfrow=c(1,1),mar=c(3,1,3,1))
              #plot density         
              s1 <- density(A[[ii]][,i]) #determine maximal common x range
              s2 <- density(A[[jj]][,i+2])
              n1 <- length(s1$x)
              n2 <- length(s2$x)             
              from <- min(s1$x[1],s2$x[1])
              to <- max(s1$x[n1],s2$x[n2])
              n <- max(n1,n2)
              s1 <- density(A[[ii]][,i],n=n,from=from,to=to) #compute both densities (jj~robust)            
              s2 <- density(A[[jj]][,i+2],n=n,from=from,to=to)
              maximum <- max(max(s1$y),s2$y) #compute maximal y value
              xlab <- paste("N =", s1$n)
              if (q==1) #you are currently working with theta
                {
                  plot(s1$x,s1$y,type="l",lwd=2,main=substitute(paste("Estimated densities of ",
                       hat(theta)[ii],sep=""),list(ii=i-2)),
                       xlab=xlab,ylab="",ylim=c(0,maximum*1.1),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                  lines(s2$x,s2$y,type="l",lty=2,lwd=2)
                  abline(h = 0, lwd = 0.1, col = "gray")
                  legend(s2$x[1],maximum*1.15,lty=c(1,2),lwd=2,c("EMM", "REMM"),cex=1.7,horiz=T,y.intersp=1.3,bty="n")
                }
              else #q==2, i.e. you work with rho
                {
                  plot(s1$x,s1$y,type="l",lwd=2,main=substitute(paste("Estimated densities of ",
                       hat(rho)[ii],sep=""),list(ii=i-2)),
                       xlab=xlab,ylab="",ylim=c(0,maximum*1.1),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                  lines(s2$x,s2$y,type="l",lty=2,lwd=2)
                  abline(h = 0, lwd = 0.1, col = "gray")
                  legend(s2$x[1], maximum*1.15,lty=c(1,2),lwd=2,c("EMM", "REMM"), cex=1.3,horiz=T,y.intersp=1.3,bty="n")
                }
            }
        }
      else
        {
          return(cat(paste("Results ",step[q]," or robust results ",step[q]," are missing/n", sep="")))
        }
    }

  #ripetiamo la stessa analysis ma solo con le convergenti
  for (q in 1:2)
    {
      i <- FALSE
      j <- FALSE
      s <- 1
      name <- names(A)
      for (nome in name)
        {
          if (nome==res[q]) 
            {
              i <- TRUE
              ii <- s
            }
          if (nome==res.rob[q])
            {
              j <- TRUE
              jj <- s
            }
          if (i & j) break
          s <- s+1
        }
      if (i & j)
        {
        #A e' una matrice contenente i coeff. stimati
          d <- dim (A[[ii]])
          names.col <- c(dimnames(A[[ii]])[[2]])

        #se il numero di simulazioni e' uguale a 1 termina
          if (d[1]==1)
            {
              return(print("Il numero di simulazioni e' 1"))
            }
          for (i in 3:d[2])
            { 
              par(ask=T)
              par(mfrow=c(1,1),mar=c(3,1,3,1))
              #plot of the densities          
              converged <- (A[[ii]][,1]==0)&(A[[jj]][,1]==0) #select joint converged simulations
              s1 <- density(A[[ii]][converged,i])
              s2 <- density(A[[jj]][converged,i+2])
              
              n1 <- length(s1$x) #determine maximal common x range
              n2 <- length(s2$x)             
              from <- min(s1$x[1],s2$x[1])
              to <- max(s1$x[n1],s2$x[n2])
              n <- max(n1,n2)
              s1 <- density(A[[ii]][converged,i],n=n,from=from,to=to) #compute both densities (jj~robust)
              s2 <- density(A[[jj]][converged,i+2],n=n,from=from,to=to)

              maximum <- max(max(s1$y),s2$y) #compute maximal y value
              postscript(paste(name.coeff[q],i-2,".comp.eps",sep=""),horizontal=FALSE,onefile=FALSE,height=5,width=5) #open output file
              xlab <- paste("N =", s1$n)
              if (q==1) #you are currently working with theta
                {
                  plot(s1$x,s1$y,type="l",lwd=2,xlab=xlab,ylab="",ylim=c(0,maximum*1.1),
                       main=substitute(
                         paste("Estimated densities of ",hat(theta)[ii],sep=""),
                         list(ii=i-2)),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                  lines(s2$x,s2$y,type="l",lty=2,lwd=2)
                  abline(h = 0, lwd = 0.1, col = "gray")
                  legend(s2$x[1], maximum*1.20,lty=c(1,2),lwd=2,c("EMM", "REMM"), cex=1.3,horiz=T,y.intersp=1.3,bty="n")
                }
              else #q==2, i.e. you work with rho
                {
                  plot(s1$x,s1$y,type="l",lwd=2,xlab=xlab,ylab="",ylim=c(0,maximum*1.1),
                       main=substitute(
                         paste("Estimated densities of ",hat(rho)[ii],sep=""),
                        list(ii=i-2)),cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
                  lines(s2$x,s2$y,type="l",lty=2,lwd=2)
                  abline(h = 0, lwd = 0.1, col = "gray")
                  legend(s2$x[1], maximum*1.20,lty=c(1,2),lwd=2,c("EMM", "REMM"), cex=1.3,horiz=T,y.intersp=1.3,bty="n")
                }
              dev.off() #close device, i.e. output file
            }
        }
      else
        {
          return(cat(paste("Results ",step[q]," or robust results ",step[q]," are missing/n", sep="")))
        }
    }
}



z.analizza.serie <- function(A)
{
  m <- mean(A$series)
  ss <- sqrt(var(A$series))
  par(ask=T)
  par(mfrow=c(2,2))
  plot(A$series,type="l",ylab="",main="series")
  xlab <- paste("Mean =", formatC(m), "Stdv =", formatC(ss))  
  boxplot(A$series,xlab=xlab,main="Boxplot")
  s <- density(A$series)  
  xlab <- paste("N =", s$n, "  Bandwidth =", formatC(s$bw))
  plot(s$x,s$y,type="l",xlab=xlab,ylab="Density", 
       main="Estimated density compared with the normal density")
  normal.d <- dnorm(s$x,m,ss)
  lines(s$x,normal.d,type="l",lty=2)
  abline(h = 0, lwd = 0.1, col = "gray")
  qqnorm((A$series-m)/ss)
  abline(0,1)



  i <- FALSE
  for (nome in names(A))
    {
      if (nome=="series.not.obs") 
        {
          i <- TRUE
          break  
        }
  }
  if (i)
    {
      m <- mean(A$series.not.obs)
      ss <- sqrt(var(A$series.not.obs))
      par(ask=T)
      par(mfrow=c(3,1))
      plot(A$series.not.obs,type="l",ylab="",main="unobserved series")
      plot(A$series.not.obs**2,type="l",ylab="",main="square of unobserved series")
      s <- density(A$series.not.obs)  
      xlab <- paste("N =", s$n, "  Bandwidth =", formatC(s$bw))
      plot(s$x,s$y,type="l",xlab=xlab,ylab="Density", 
           main="Estimated density")
    }
}


z.analizza.serie.c <- function(A)
{
  #questa funzione fa un plot della serie contaminata, un suo boxplot,
  #una stima della densita' comparata alla normale, e da ultimo fa un
  #qqplot con la normale come riferimento
  m <- mean(A$series.c)
  ss <- sqrt(var(A$series.c))
  par(ask=T)
  par(mfrow=c(2,2))
  plot(A$series.c,type="l",ylab="",main="contaminated series")
  xlab <- paste("Mean =", formatC(m), "Stdv =", formatC(ss))  
  boxplot(A$series.c,xlab=xlab,main="Boxplot")
  s <- density(A$series.c)  
  xlab <- paste("N =", s$n, "  Bandwidth =", formatC(s$bw))
  plot(s$x,s$y,type="l",xlab=xlab,ylab="Density", 
       main="Estimated density compared with the normal density")
  normal.d <- dnorm(s$x,m,ss)
  lines(s$x,normal.d,type="l",lty=2)
  abline(h = 0, lwd = 0.1, col = "gray")
  qqnorm((A$series.c-m)/ss)
  abline(0,1)


  #verifica l'esistenza della serie non osservabile
  i <- FALSE
  for (nome in names(A))
    {
      if (nome=="series.not.obs") 
        {
          i <- TRUE
          break  
        }
    }
  
  #sta funzione fa un plot della serie contaminata non osservabile,
  #il plot dei suoi quadrati,
  #una stima della densita'
  if (i)
    {
      m <- mean(A$series.not.obs.c)
      ss <- sqrt(var(A$series.not.obs.c))
      par(ask=T)
      par(mfrow=c(3,1))
      plot(A$series.not.obs.c,type="l",ylab="",main="contaminated unobservable series")
      plot(A$series.not.obs.c**2,type="l",ylab="",main="square of cont. unobs. series")
      s <- density(A$series.not.obs.c)  
      xlab <- paste("N =", s$n, "  Bandwidth =", formatC(s$bw))
      plot(s$x,s$y,type="l",xlab=xlab,ylab="Density", 
           main="Estimated density")
    }
}





z.paragona <- function(A,inizio=1,fine=length(A$series))
{
  cex.main1 <- 2.5
  cex.lab1 <- 1.5
  cex.axis1 <- 1.5
  if(fine!=length(A$series) | inizio!=1)
    {
      add.on <- paste(inizio,"_",fine,".eps",sep="")
    }
  else
    {
      add.on <- ".eps" 
    }
  #verifica l'esistenza della serie weights
  i <- FALSE
  for (nome in names(A))
    {
      if (nome=="weights") 
        {
          i <- TRUE
          break  
        }
  }
  par.old <-  par()
  par(ask=T,mar=c(3,1,3,1))
  #fai un grafico con la differenza tra la serie contaminata e quella non contaminata,
  #la serie contaminata, i pesi e la serie non contaminata.
  if (i)
    {
      par(mfrow=c(2,2))     
      plot(inizio:fine,A$series.c[inizio:fine]-A$series[inizio:fine],type="h",
           ylab="",xlab="Index", main="Cont. - Uncont. Series", 
           cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      plot(inizio:fine,A$series.c[inizio:fine],type="l",ylab="",main="Contaminated Series",
           ,xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      plot(inizio:fine,1-A$weights[inizio:fine],ylim=c(0,1), type="h",ylab="",main="1 - Weights",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      abline(h = 1, lwd = 0.1, col = "gray")
      plot(inizio:fine,A$series[inizio:fine],type="l",ylab="",main="Series",
           xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
    }
  else   #se la serie dei pesi non e' disponibile
    {
      par(mfrow=c(3,1))
      plot(inizio:fine,A$series.c[inizio:fine]-A$series[inizio:fine],type="h",
           ylab="",main="Cont. - Uncont. Series",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      plot(inizio:fine,A$series.c[inizio:fine],type="l",ylab="",main="Contaminated Series",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      plot(inizio:fine,A$series[inizio:fine],type="l",ylab="",main="Series",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)     

    }

  if (i)
    {
      par(mfrow=c(1,1))
      postscript(paste("contamination_points",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)  
      plot(inizio:fine,A$series.c[inizio:fine]-A$series[inizio:fine],type="h",
           ylab="", main="Cont. - Uncont. Series",
           xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      dev.off()
      
      postscript(paste("contaminated_series",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7) 
      plot(inizio:fine,A$series.c[inizio:fine],type="l",ylab="",main="Contaminated Series",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      dev.off()
      
      postscript(paste("weights",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7) 
      plot(inizio:fine,1-A$weights[inizio:fine],ylim=c(0,1),type="h",ylab="",main="1 - Weights",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      abline(h = 1, lwd = 1, lty=2, col = "black")
      dev.off()
      
      postscript(paste("uncontaminated_series",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7) 
      plot(inizio:fine,A$series[inizio:fine],type="l",ylab="",main="Uncontaminated Series",
            xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      dev.off()
    }
  else   #se la serie dei pesi non e' disponibile
    {
      postscript(paste("contamination_points",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
      plot(inizio:fine,A$series.c[inizio:fine]-A$series[inizio:fine],type="h",
           ylab="",main="Contaminated - Uncont. Series",
           xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      dev.off()

      postscript(paste("contaminated_series",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
      plot(inizio:fine,A$series.c[inizio:fine],type="l",ylab="",main="Contaminated Series",
           xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)
      dev.off()

      postscript(paste("uncontaminated_series",add.on,sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
      plot(inizio:fine,A$series[inizio:fine],type="l",ylab="",main="Uncontaminated Series",
           xlab="Index",cex.main=cex.main1,cex.axis=cex.axis1,cex.lab=cex.lab1)     
      dev.off()
    }

  #verifica l'esistenza della serie non osservabile
  j <- FALSE
  for (nome in names(A))
    {
      if (nome=="series.not.obs") 
        {
          j <- TRUE
          break  
        }
  }
  #se la serie osservabile esiste, fai il medesimo grafico come nel punto precedente
  if (j)
    {
      if (i)
        {
          par(mfrow=c(2,2))     
          plot(inizio:fine,A$series.not.obs.c[inizio:fine]-A$series.not.obs[inizio:fine],type="h",
               ylab="", xlab="Index",main="Contaminated - Uncontaminated Unobservable Series")
          plot(inizio:fine,A$series.not.obs.c[inizio:fine],type="l",ylab="",xlab="Index",
               main="Contaminated Unobservable Series")
          plot(inizio:fine,1-A$weights[inizio:fine],ylim=c(0,1),type="h",ylab="",xlab="Index",main="1 - Weights")
          plot(inizio:fine,A$series.not.obs[inizio:fine],type="l",ylab="",xlab="Index",main="Unobservable Series")
        }
      else  #se la serie dei pesi non e' disponibile
        {
          par(mfrow=c(3,1))
          plot(inizio:fine,A$series.not.obs.c[inizio:fine]-A$series.not.obs[inizio:fine],type="h",
               ylab="",xlab="Index",main="Contaminated - Uncontaminated Unobservable Series")
          plot(inizio:fine,A$series.not.obs.c[inizio:fine],type="l",ylab="",
               xlab="Index",main="Contaminated Unobservable Series")
          plot(inizio:fine,A$series.not.obs[inizio:fine],type="l",ylab="",
               xlab="Index",main="Unobservable Series")      
        }
    }
  par <- par.old
}

z.rap.snp <- function(theta,epsilon,inizio=-4,fine=4,punti=100)
#theta contiene i parametri, theta0=1 di norma
{
cex.main1 <- 2.5
cex.lab1 <- 1.5
cex.axis1 <- 1.5
d.pol_length(theta)-1
m.theta_matrix(theta)
Q_matrix(c(1,0,1,0,3,0,15,0,105,0,1,0,3,0,15,0,105,
0,1,0,3,0,15,0,105,0,945,0,3,0,15,0,105,0,945,0,3,
0,15,0,105,0,945,0,10395,0,15,0,105,0,945,0,10395,
0,15,0,105,0,945,0,10395,0,135135,0,105,0,945,0,
10395,0,135135,0,105,0,945,0,10395,0,135135,0,2027025),nrow=9)
M_Q[1:(d.pol+1),1:(d.pol+1)]
denominator_t(m.theta)%*%M%*%m.theta
y_inizio+(0:((fine-inizio)*punti))/punti
i_1
s_y
normal.d_dnorm(y)
for (x in y)
{
v_1:d.pol
z_x^v
z_matrix(c(1,z))
value_((t(z)%*%theta)^2 + epsilon)*normal.d[i]/denominator[1,1]
s[i]_value[1,1]
i_i+1
}
max1_max(normal.d)
max2_max(s)
maximum_max(c(max1,max2))
if (maximum == max2)
{
plot(y,s,type="l",ylab="",xlab="",lwd=2,cex.axis=cex.axis1,cex.lab=cex.lab1)
lines(y,normal.d,type="l",lty=2,lwd=2)
legend(2.0,maximum,lty=c(1,2),lwd=2,c(paste("SNP K=",d.pol,sep=""),"N(0,1)"), cex=1.7,horiz=F,
y.intersp=1.3,bty="n") #, bg='gray90'

postscript(paste("snp",d.pol,".eps",sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
plot(y,s,type="l",ylab="",xlab="",lwd=2,cex.axis=cex.axis1,cex.lab=cex.lab1)
lines(y,normal.d,type="l",lty=2,lwd=2)
legend(2.0,maximum,lty=c(1,2),lwd=2,c(paste("SNP K=",d.pol,sep=""),"N(0,1)"), cex=1.7,horiz=F,
y.intersp=1.3,bty="n") #, bg='gray90'
dev.off()
}
else
{
plot(y,normal.d,type="l",ylab="",xlab="",lwd=2,lty=2,cex.axis=cex.axis1,cex.lab=cex.lab1)
lines(y,s,type="l",lwd=2)
legend(2.0,maximum,lty=c(1,2),lwd=2,c(paste("SNP K=",d.pol,sep=""),"N(0,1)"), cex=1.7,horiz=F,
y.intersp=1.3,bty="n") #, bg='gray90'

postscript(paste("snp",d.pol,".eps",sep=""),horizontal=FALSE,onefile=FALSE,height=7,width=7)
plot(y,normal.d,type="l",ylab="",xlab="",lwd=2,lty=2,cex.axis=cex.axis1,cex.lab=cex.lab1)
lines(y,s,type="l",lwd=2)
legend(2.0,maximum,lty=c(1,2),lwd=2,c(paste("SNP K=",d.pol,sep=""),"N(0,1)"), cex=1.7,horiz=F,
y.intersp=1.3,bty="n") #, bg='gray90'
dev.off()
}


}



#valori approssimazione bias con snp
#contamination <- 0.001
#theta3_c(1,c(-25.025,6.006,9.17583333333333)*contamination)
#theta4_c(1,c(-25.025,-53.80375,9.17583333333333,9.96829166666666)*contamination)
#theta5_c(1,c(96.971875,-53.80375,-72.1554166666666,9.96829166666666,8.133125)*contamination)
#theta6_c(1,c(96.971875,176.42625,-72.1554166666666,-66.7750416666666,8.133125,5.11622222222222)*contamination)
#theta7_c(1,c(-164.747916666667,176.42625,189.564375,-66.7750416666666,-44.2108333333333,5.11622222222222,2.49256944444444)*contamination)
#theta8_c(1,c(-164.747916666667,-209.2715625,189.564375,126.073864583333,-44.2108333333333,-20.5969652777778,2.49256944444444,0.918328125)*contamination)

#valori approssimazione bias con snp
#thetamc3_c(1, -0.1017628714910976, 1.381032842627693E-02, 4.027254375463865E-02)
#thetamc4_c(1, -4.578177619428665E-02, -8.813844049569566E-02, 1.798298410395724E-02, 1.637760784481055E-02)
#thetamc5_c(1, 7.968847474192844E-02, -2.712898800391428E-02, -6.787489811454613E-02, 1.473152703425380E-03, 9.671136231208525E-03)
#thetamc6_c(1, 5.580400478688972E-02, 0.1243709638108777, -4.468903270825731E-02, -4.901231601334476E-02, 5.558196649614825E-03, 3.641765211657366E-03)
#thetamc7_c(1, -7.076328438754839E-02, 8.819037251045433E-02, 8.494264899040338E-02, -3.455829857706853E-02, -2.105316887205724E-02, 2.401330935234642E-03, 1.262623197177965E-03)
#thetamc8_c(1, -5.236984893177778E-02, -6.550237022678994E-02, 6.246996738221301E-02, 4.407897969424917E-02, -1.545462369526027E-02, -8.335974642799707E-03, 9.228958934726041E-04, 3.826182236270051E-04)










